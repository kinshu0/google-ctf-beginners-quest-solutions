util Package
============

:mod:`util` Package
-------------------

.. automodule:: ripyl.util
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`bitops` Module
--------------------

.. automodule:: ripyl.util.bitops
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`eng` Module
-----------------

.. automodule:: ripyl.util.eng
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`enum` Module
------------------

.. automodule:: ripyl.util.enum
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`equality` Module
------------------

.. automodule:: ripyl.util.equality
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`plot` Module
------------------

.. automodule:: ripyl.util.plot
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`stats` Module
-------------------

.. automodule:: ripyl.util.stats
    :members:
    :undoc-members:
    :show-inheritance:


