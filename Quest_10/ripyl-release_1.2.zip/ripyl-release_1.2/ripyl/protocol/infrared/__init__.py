#!/usr/bin/python

'''Infrared protocol package'''

from ripyl.protocol.infrared.ir_common import *
